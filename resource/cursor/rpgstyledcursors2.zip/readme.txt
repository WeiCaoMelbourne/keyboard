﻿=== More RPG Styled Cursor Set ===

By: Stwennin

Download: http://www.rw-designer.com/cursor-set/rpgstyledcursors2

Author's description:

I didn\'t made all of them when the first set was release, so here are all of the other left (and some extra ones too).

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.